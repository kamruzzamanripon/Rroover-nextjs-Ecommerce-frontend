# NextJs Ecommerce make from figma Image

## This figma image get from rasal ahmed

[Link](https://www.figma.com/file/dGnV13M0DEXrcPYbpzgsjL/Bengal-Shop?node-id=0%3A1)

## File Structure

---

1. pages
2. components
3. hook

---

## Home Page

## ![This is a alt text.](/public/home.jpg)

---

## Login and Register

## ![This is a alt text.](/public/login_register.png)

---

## Single Page

![This is a alt text.](/public/single_Page.png)

---

## Mini Cart

![This is a alt text.](/public/mini_cart.png)

---

## WishList Page

![This is a alt text.](/public/WishList_page.png)

---

## Cart Page

![This is a alt text.](/public/cart_page.png)

---

## Filter Page

![This is a alt text.](/public/filter.png)

---

## Brand Page

![This is a alt text.](/public/brand_page.png)

---

## Freatures Page

![This is a alt text.](/public/features_Page.png)

---

---

## Install

npm install

## rename .env.exaple file as .env then put your api link
