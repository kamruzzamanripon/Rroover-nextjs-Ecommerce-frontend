import React from 'react';

const About = () => {
    return (
        <div className="container my-10 text-center">
            <h1>this is about Page</h1>
        </div>
    );
};

export default About;