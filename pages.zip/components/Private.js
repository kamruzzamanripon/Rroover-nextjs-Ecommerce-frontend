/* eslint-disable react-hooks/rules-of-hooks */
import React from 'react';
import usePrivateRoute from '../hook/usePrivateRoute';



const Private = () => {
    return (
        <div>
            <h1>this is private page</h1>
        </div>
    );
};

export default Private;


