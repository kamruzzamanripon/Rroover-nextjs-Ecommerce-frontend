"use strict";
exports.id = 436;
exports.ids = [436];
exports.modules = {

/***/ 4436:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _category_AccordionCategories__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4435);
/* harmony import */ var _category_AccordionPriceSlider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5026);
/* harmony import */ var _category_CategoryTitleOther__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(236);
/* harmony import */ var _category_HeroBanner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3782);
/* harmony import */ var _category_Products__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7458);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_category_Products__WEBPACK_IMPORTED_MODULE_7__]);
_category_Products__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];








const Category = ()=>{
    const { 0: displayStyle , 1: setDisplayStyle  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('grid');
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const { query  } = router;
    const { 0: filterPrice , 1: setFilterPrice  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const { 0: orderingProduct , 1: setOrderingProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('asc');
    //console.log("display orderingProduct", orderingProduct)
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "container",
        id: "modalRoot",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "sm:flex",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: " mb-8 sm:w-1/3 md:w-1/4 mx-6 sm:mx-0",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_category_AccordionCategories__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_category_AccordionPriceSlider__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            setFilterPrice: setFilterPrice
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: " sm:w-2/3 md:w-3/4 mx-6",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_category_HeroBanner__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_category_CategoryTitleOther__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            setDisplayStyle: setDisplayStyle,
                            setOrderingProduct: setOrderingProduct
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_category_Products__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            displayStyle: displayStyle,
                            filterPrice: filterPrice,
                            orderingProduct: orderingProduct
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Category);

});

/***/ }),

/***/ 4435:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3282);
/* harmony import */ var react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__);

/* eslint-disable react/jsx-key */ 


const AccordionCategories = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.Accordion, {
        allowZeroExpanded: true,
        children: Array(6).fill().map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.AccordionItem, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.AccordionItemHeading, {
                        className: "relative",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.AccordionItemButton, {
                            className: "accordion__button",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "inline-block text-base",
                                children: "Fruits"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.AccordionItemPanel, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.Accordion, {
                            allowZeroExpanded: true,
                            className: "className=\"accordion__panel\"",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.AccordionItem, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.AccordionItemHeading, {
                                            className: "relative",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.AccordionItemButton, {
                                                className: "accordion__button sibling",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                    className: "inline-block text-sm",
                                                    children: "Local Furits"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.AccordionItemPanel, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                children: "Fresh Fruits"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.AccordionItem, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.AccordionItemHeading, {
                                            className: "relative",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.AccordionItemButton, {
                                                className: "accordion__button sibling",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                    className: "inline-block text-sm",
                                                    children: "Foreign Furites"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_accessible_accordion__WEBPACK_IMPORTED_MODULE_2__.AccordionItemPanel, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                children: "Fresh Fruits"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }, index)
        )
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AccordionCategories);


/***/ }),

/***/ 5026:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ category_AccordionPriceSlider)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-accessible-accordion"
var external_react_accessible_accordion_ = __webpack_require__(3282);
// EXTERNAL MODULE: external "rc-slider"
var external_rc_slider_ = __webpack_require__(1817);
var external_rc_slider_default = /*#__PURE__*/__webpack_require__.n(external_rc_slider_);
;// CONCATENATED MODULE: ./components/category/PriceSlider.js




const createSliderWithTooltip = (external_rc_slider_default()).createSliderWithTooltip;
const Range = createSliderWithTooltip((external_rc_slider_default()).Range);
const PriceSlider = ({ setFilterPrice  })=>{
    const { 0: sliderValue , 1: setSliderValue  } = (0,external_react_.useState)(0);
    (0,external_react_.useEffect)(()=>{
        setFilterPrice(sliderValue);
    }, [
        sliderValue,
        setFilterPrice
    ]);
    //console.log("slider Value", sliderValue)
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: "mt-5 mb-1",
                children: [
                    "Select Price: ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "font-bold",
                        children: sliderValue
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((external_rc_slider_default()), {
                min: 0,
                max: 1000,
                value: sliderValue,
                onChange: setSliderValue,
                railStyle: {
                    height: 2
                },
                handleStyle: {
                    height: 20,
                    width: 20,
                    marginLeft: -12,
                    marginTop: -10,
                    backgroundColor: "green",
                    border: 0
                },
                trackStyle: {
                    background: "none"
                }
            })
        ]
    }));
};
/* harmony default export */ const category_PriceSlider = (PriceSlider);

;// CONCATENATED MODULE: ./components/category/AccordionPriceSlider.js





const AccordionPriceSlider = ({ setFilterPrice  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(external_react_accessible_accordion_.Accordion, {
        preExpanded: [
            'a'
        ],
        allowZeroExpanded: true,
        className: "mt-8",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_accessible_accordion_.AccordionItem, {
            uuid: "a",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(external_react_accessible_accordion_.AccordionItemHeading, {
                    className: "relative",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_accessible_accordion_.AccordionItemButton, {
                        className: "accordion__button",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            children: "Price"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(external_react_accessible_accordion_.AccordionItemPanel, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(category_PriceSlider, {
                        setFilterPrice: setFilterPrice
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const category_AccordionPriceSlider = (AccordionPriceSlider);


/***/ }),

/***/ 236:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _heroicons_react_solid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1143);
/* harmony import */ var _heroicons_react_solid__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_solid__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);




const CategoryTitleOther = ({ setDisplayStyle , setOrderingProduct  })=>{
    const { 0: Title , 1: setTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('Sample Category Name');
    const { 0: productCount , 1: setProductCount  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('');
    const categoryName = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state?.homePageItems?.categories?.ctegeoryItemsById?.name
    );
    const categoryProducts = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state?.homePageItems?.categories?.ctegeoryItemsById?.products
    );
    const categoryProductCount = categoryProducts ? categoryProducts.length : '';
    const brandName = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state?.homePageItems?.brands?.brandItemsById[0]?.brand?.name
    );
    const brandProducts = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state?.homePageItems?.brands?.brandItemsById
    );
    const brandProductCount = brandProducts ? brandProducts.length : '';
    //console.log("produt orderingProduct", orderingProduct)
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setTitle(categoryName || brandName);
        setProductCount(categoryProductCount || brandProductCount);
    }, [
        categoryName,
        brandName,
        brandProductCount,
        categoryProductCount
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "my-8",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: "font-bold text-4xl",
                    children: Title
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "lg:flex items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "lg:w-1/2"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "lg:w-1/2 flex items-center justify-between lg:justify-end",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    productCount,
                                    " Products Found"
                                ]
                            }),
                            " \xa0 \xa0",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_solid__WEBPACK_IMPORTED_MODULE_1__.MenuAlt3Icon, {
                                    onClick: ()=>setDisplayStyle('menu')
                                    ,
                                    className: "h-8 cursor-pointer"
                                })
                            }),
                            " \xa0 \xa0",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_solid__WEBPACK_IMPORTED_MODULE_1__.ViewGridIcon, {
                                    onClick: ()=>setDisplayStyle('grid')
                                    ,
                                    className: "h-8 cursor-pointer"
                                })
                            }),
                            "  \xa0",
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                name: "",
                                id: "",
                                onChange: (e)=>setOrderingProduct(e.target.value)
                                ,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                        value: "asc",
                                        children: "Default Sorting"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                        value: "asc",
                                        children: "ASC Sorting"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                        value: "desc",
                                        children: "DESC Sorting"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoryTitleOther);


/***/ }),

/***/ 3782:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ category_HeroBanner)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: ./public/images/hero-2.png
/* harmony default export */ const hero_2 = ({"src":"/_next/static/media/hero-2.be27c81a.png","height":300,"width":1275,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAIAAADq9gq6AAAAOklEQVR42mP4+gUCPn/68u3tjd2PD+ftX1FxdNcihrdv37x5++bd23cv3ry4fnXPxSMbTm6YvnZyJwALICebx4uUwgAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/category/HeroBanner.js





const HeroBanner = ()=>{
    const { 0: heroImage , 1: setHeroImage  } = (0,external_react_.useState)('');
    const categoryImage = (0,external_react_redux_.useSelector)((state)=>state?.homePageItems?.categories?.ctegeoryItemsById?.image
    );
    const brandImage = (0,external_react_redux_.useSelector)((state)=>state?.homePageItems?.brands?.brandItemsById[0]?.brand?.image
    );
    //console.log("hero", brandImage)
    (0,external_react_.useEffect)(()=>{
        setHeroImage(categoryImage || brandImage);
    }, [
        brandImage,
        categoryImage
    ]);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "mb-5 relative ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                src: heroImage ? "http://laravelapi.kamruzzaman.xyz/" + heroImage : hero_2,
                height: "25px",
                width: "100%",
                layout: "responsive",
                alt: "imageThree"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "absolute left-8 top-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-orange-700 text-xl mb-1 mt-3 sm:mt-1 md:mt-4 xl:mt-28",
                        children: "Buy 1 Get 1"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                        className: "bs-dark-green-color text-xl xl:text-2xl",
                        children: [
                            "Up to 30% Discount on ",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            " Selected Items"
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const category_HeroBanner = (HeroBanner);


/***/ }),

/***/ 7458:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_Modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4057);
/* harmony import */ var _common_ProductItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6499);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_Modal__WEBPACK_IMPORTED_MODULE_3__]);
_common_Modal__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const Products = ({ displayStyle , filterPrice , orderingProduct  })=>{
    const { 0: modal , 1: setModal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: modalProductInfo , 1: setModalProductInfo  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: productArray , 1: setProductArray  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const categoryProduct = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state?.homePageItems?.categories?.ctegeoryItemsById?.products
    );
    const brandProducts = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state?.homePageItems?.brands?.brandItemsById
    );
    const categoryProductPriceFilter = categoryProduct?.filter((item, index, array)=>filterPrice ? item.actual_price <= filterPrice : array
    );
    const brandProductsPriceFilter = brandProducts?.filter((item, index, array)=>filterPrice ? item.actual_price <= filterPrice : array
    );
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setProductArray(categoryProductPriceFilter || brandProductsPriceFilter);
    }, [
        categoryProduct,
        filterPrice,
        brandProductsPriceFilter,
        categoryProductPriceFilter
    ]);
    if (orderingProduct === 'desc') {
        productArray.sort((a, b)=>a.actual_price > b.actual_price ? -1 : 1
        );
    } else {
        productArray.sort((a, b)=>a.actual_price < b.actual_price ? -1 : 1
        );
    }
    //console.log("Product display orderingProduct", allProduct)
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `${displayStyle === 'grid' ? "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 2xl:grid-cols-4" : ''}`,
                    children: [
                        productArray.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_ProductItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                setModal: setModal,
                                id: index,
                                displayStyle: displayStyle,
                                setModalProductInfo: setModalProductInfo,
                                productItemInfo: item
                            }, index)
                        ),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Modal__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            modal: modal,
                            setModal: setModal,
                            modalProductInfo: modalProductInfo
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-16 text-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: "bs-dark-green-bg text-white px-10 py-4 rounded-full inline-block",
                    children: "Load More"
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Products);

});

/***/ }),

/***/ 6499:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _heroicons_react_solid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1143);
/* harmony import */ var _heroicons_react_solid__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_solid__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hook_useCartHook__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2656);
/* harmony import */ var _public_images_product_1_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3796);








const ProductItem = ({ setModal , id , displayStyle , key , setModalProductInfo , productItemInfo  })=>{
    const productItemId = productItemInfo.id;
    const { addItemToCart , increaseProduct , decrementProduct , cartQuantity  } = (0,_hook_useCartHook__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(productItemId);
    const productImageParse = productItemInfo.image ? JSON.parse(productItemInfo?.image) : "";
    const productImage = productImageParse[0];
    //console.log(id)
    const productInfo = {
        id: productItemId,
        title: productItemInfo?.name,
        price: productItemInfo?.actual_price,
        detail: "lorem",
        image: productImage
    };
    const addProduct = ()=>{
        addItemToCart(productInfo);
    };
    const increament = ()=>{
        increaseProduct(productItemId);
    };
    const decrement = ()=>{
        decrementProduct(productItemId);
    };
    const viewModal = ()=>{
        setModal(true);
        setModalProductInfo(productItemInfo);
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "mb-14 sm:mb-5",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "category-carousel mb-16 text-center mr-5 group",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "single-bs-product",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${displayStyle === "grid" ? "h-72 product-img group relative" : "h-80 product-img group relative flex items-center space-x-5 justify-between"}`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "h-auto p-4",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    src: productImage ? "http://laravelapi.kamruzzaman.xyz/" + productImage : _public_images_product_1_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                    height: "310",
                                    width: "310",
                                    objectFit: "contain"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-10",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                        className: "text-xl mb-3",
                                        children: productItemInfo?.name
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "font-medium bs-dark-orange-color",
                                                children: [
                                                    "$",
                                                    productItemInfo?.actual_price
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("del", {
                                                className: "text-gray-400",
                                                children: [
                                                    "$",
                                                    productItemInfo?.discount_price
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            displayStyle === "menu" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "hidden md:block w-1/4 text-justify",
                                children: productItemInfo?.details
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "product-img-hover absolute h-full w-full top-0 left-0 flex justify-center items-center hidden transition duration-20000 ease-in group-hover:flex",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "bg-black absolute h-full w-full opacity-60"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                        className: "absolute left-0 bottom-0 bg-gray-200 p-2 w-full flex items-center justify-center cursor-pointer",
                                        onClick: viewModal,
                                        children: [
                                            "Details",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_solid__WEBPACK_IMPORTED_MODULE_1__.ArrowRightIcon, {
                                                className: "h-5 ml-3 transition group-first:hover:ml-5"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "relative z-10",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex justify-center items-center text-4xl text-white mb-8",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: `${cartQuantity && cartQuantity !== 0 ? "" : "hidden"} h-12 w-12 border border-white rounded-full`,
                                                        onClick: decrement,
                                                        children: "-"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: "px-6",
                                                        children: [
                                                            " ",
                                                            cartQuantity,
                                                            " "
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: `${cartQuantity && cartQuantity !== 0 ? "" : "hidden"} h-12 w-12 border border-white rounded-full`,
                                                        onClick: increament,
                                                        children: "+"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "bs-dark-green-bg text-white px-8 py-2 rounded-full inline-block",
                                                onClick: addProduct,
                                                children: "Add to card"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        }, key)
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductItem);


/***/ })

};
;