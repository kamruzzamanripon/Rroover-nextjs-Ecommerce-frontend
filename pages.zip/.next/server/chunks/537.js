"use strict";
exports.id = 537;
exports.ids = [537];
exports.modules = {

/***/ 537:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ wrapper)
/* harmony export */ });
/* unused harmony export makeStore */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store_slices_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7294);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_slices_index__WEBPACK_IMPORTED_MODULE_2__]);
_store_slices_index__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];



const devMode = "production" === 'development';
//The global store setup
const makeStore = ()=>(0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
        reducer: _store_slices_index__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
        devTools: devMode
    })
;
const wrapper = (0,next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__.createWrapper)(makeStore, {
    debug: devMode
});

});

/***/ }),

/***/ 449:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__]);
_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];


const initialState = {
    authLoading: false,
    userInfo: {}
};
const authenticationSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'authenticationSlice',
    initialState,
    reducers: {},
    extraReducers: {
        // Login Reducer
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .login.pending */ .x4.pending]: (state)=>{
            state.authLoading = true;
        },
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .login.fulfilled */ .x4.fulfilled]: (state, { payload  })=>{
            state.authLoading = false;
            state.userInfo = payload;
        },
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .login.rejected */ .x4.rejected]: (state)=>{
            state.authLoading = false;
        },
        // Logout Reducer
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .logout.pending */ .kS.pending]: (state)=>{
            state.authLoading = true;
        },
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .logout.fulfilled */ .kS.fulfilled]: (state, { payload  })=>{
            state.authLoading = false;
            state.userInfo = payload;
        },
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .logout.rejected */ .kS.rejected]: (state)=>{
            state.authLoading = false;
        },
        // registration Reducer
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .registration.pending */ .l9.pending]: (state)=>{
            state.authLoading = true;
        },
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .registration.fulfilled */ .l9.fulfilled]: (state, { payload  })=>{
            state.authLoading = false;
            state.userInfo = payload;
        },
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .registration.rejected */ .l9.rejected]: (state)=>{
            state.authLoading = false;
        },
        // forgetPassword Reducer
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .forgetPassword.pending */ .o9.pending]: (state)=>{
            state.authLoading = true;
        },
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .forgetPassword.fulfilled */ .o9.fulfilled]: (state, { payload  })=>{
            state.authLoading = false;
            state.userInfo = payload;
        },
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .forgetPassword.rejected */ .o9.rejected]: (state)=>{
            state.authLoading = false;
        },
        // forgetPasswordReset Reducer
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .forgetPasswordReset.pending */ .oh.pending]: (state)=>{
            state.authLoading = true;
        },
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .forgetPasswordReset.fulfilled */ .oh.fulfilled]: (state, { payload  })=>{
            state.authLoading = false;
            state.userInfo = payload;
        },
        [_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_1__/* .forgetPasswordReset.rejected */ .oh.rejected]: (state)=>{
            state.authLoading = false;
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authenticationSlice.reducer);

});

/***/ }),

/***/ 2135:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Uv": () => (/* binding */ mainSliderData),
/* harmony export */   "eb": () => (/* binding */ categoryData),
/* harmony export */   "Nw": () => (/* binding */ brandData),
/* harmony export */   "k4": () => (/* binding */ dealOfTheWeek),
/* harmony export */   "db": () => (/* binding */ singleCategoryByIdData),
/* harmony export */   "Y4": () => (/* binding */ singleBrandByIdData)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const mainSliderData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('homeSlice/mainSliderdata', async ()=>{
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${"http://laravelapi.kamruzzaman.xyz/api/v1/frontend"}/main-banner`);
        //console.log("Hello")
        //console.log("mainslider server", res)
        return res.data.data;
    } catch (e) {
        console.log("mainslider server", e.response);
    }
});
const categoryData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('homeSlice/categoryData', async ()=>{
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${"http://laravelapi.kamruzzaman.xyz/api/v1/frontend"}/category-list`);
        return res.data.data;
    } catch (e) {
        console.log(e.response);
    }
});
const brandData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('homeSlice/brandData', async ()=>{
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${"http://laravelapi.kamruzzaman.xyz/api/v1/frontend"}/brand-list`);
        return res.data.data;
    } catch (e) {
        console.log(e.response);
    }
});
const dealOfTheWeek = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('homeSlice/dealOfTheWeek', async ()=>{
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${"http://laravelapi.kamruzzaman.xyz/api/v1/frontend"}/exclusive-deals`);
        return res.data.data;
    } catch (e) {
        console.log(e.response);
    }
});
const singleCategoryByIdData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('homeSlice/singleCategoryById', async (productId)=>{
    try {
        //console.log('single category axios', productId)
        const res = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${"http://laravelapi.kamruzzaman.xyz/api/v1/frontend"}/single-category/${productId}`);
        console.log('axior', productId);
        return res.data.data;
    } catch (e) {
        console.log(e.response);
    }
});
const singleBrandByIdData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('homeSlice/singleBrandByIdData', async (brandId)=>{
    try {
        //console.log('single category axios', productId)
        const res = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${"http://laravelapi.kamruzzaman.xyz/api/v1/frontend"}/single-brand/${brandId}`);
        //console.log('axior', productId)
        return res.data.data;
    } catch (e) {
        console.log(e.response);
    }
});


/***/ }),

/***/ 7630:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export homePageSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2135);


const initialState = {
    mainSlider: {
        loading: false,
        items: [],
        categories: []
    },
    categories: {
        categoryLoading: false,
        categoryItems: [],
        ctegeoryItemsById: []
    },
    brands: {
        brandLoading: false,
        brandItems: [],
        brandItemsById: []
    },
    dealOfTheWeek: {
        dealOfTheWeekLoading: false,
        dealOfTheWeektems: []
    }
};
const homePageSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "homePageSlice",
    initialState,
    reducers: {},
    extraReducers: {
        // Main Slider Reducer
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .mainSliderData.pending */ .Uv.pending]: (state)=>{
            state.mainSlider.loading = true;
        },
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .mainSliderData.fulfilled */ .Uv.fulfilled]: (state, { payload  })=>{
            state.mainSlider.loading = false;
            state.mainSlider.items = payload;
        },
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .mainSliderData.rejected */ .Uv.rejected]: (state)=>{
            state.mainSlider.loading = false;
        },
        // Category Reducer
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .categoryData.pending */ .eb.pending]: (state)=>{
            state.categories.categoryLoading = true;
        },
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .categoryData.fulfilled */ .eb.fulfilled]: (state, { payload  })=>{
            state.categories.categoryLoading = false;
            state.categories.categoryItems = payload;
        },
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .categoryData.rejected */ .eb.rejected]: (state)=>{
            state.categories.categoryLoading = false;
        },
        //Deals of the Week Reducer
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .brandData.pending */ .Nw.pending]: (state)=>{
            state.brands.brandLoading = true;
        },
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .brandData.fulfilled */ .Nw.fulfilled]: (state, { payload  })=>{
            state.brands.brandLoading = false;
            state.brands.brandItems = payload;
        },
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .brandData.rejected */ .Nw.rejected]: (state)=>{
            state.brands.brandLoading = false;
        },
        //Deals of the Week Reducer
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .dealOfTheWeek.pending */ .k4.pending]: (state)=>{
            state.dealOfTheWeek.dealOfTheWeekLoading = true;
        },
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .dealOfTheWeek.fulfilled */ .k4.fulfilled]: (state, { payload  })=>{
            state.dealOfTheWeek.dealOfTheWeekLoading = false;
            state.dealOfTheWeek.dealOfTheWeektems = payload;
        },
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .dealOfTheWeek.rejected */ .k4.rejected]: (state)=>{
            state.dealOfTheWeek.dealOfTheWeekLoading = false;
        },
        //single Category By Id Data Reducer
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .singleCategoryByIdData.pending */ .db.pending]: (state)=>{
            state.categories.categoryLoading = true;
        },
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .singleCategoryByIdData.fulfilled */ .db.fulfilled]: (state, { payload  })=>{
            state.categories.categoryLoading = false;
            state.categories.ctegeoryItemsById = payload;
        },
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .singleCategoryByIdData.rejected */ .db.rejected]: (state)=>{
            state.categories.categoryLoading = false;
        },
        //single Brand By Id Data Reducer
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .singleBrandByIdData.pending */ .Y4.pending]: (state)=>{
            state.brands.brandItemsById = true;
        },
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .singleBrandByIdData.fulfilled */ .Y4.fulfilled]: (state, { payload  })=>{
            state.brands.brandItemsById = false;
            state.brands.brandItemsById = payload;
        },
        [_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_1__/* .singleBrandByIdData.rejected */ .Y4.rejected]: (state)=>{
            state.brands.brandItemsById = false;
        }
    }
});
//export const {mainSlider} = homePageSlice.actions
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (homePageSlice.reducer);


/***/ }),

/***/ 7294:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6520);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_reducers__WEBPACK_IMPORTED_MODULE_1__]);
_reducers__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];


const reducer = (state, action)=>{
    if (action.type === next_redux_wrapper__WEBPACK_IMPORTED_MODULE_0__.HYDRATE) {
        return {
            ...state,
            ...action.payload
        };
    }
    return (0,_reducers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(state, action);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (reducer);

});

/***/ }),

/***/ 6520:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _authenticationSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(449);
/* harmony import */ var _cartSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5808);
/* harmony import */ var _homePageSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7630);
/* harmony import */ var _userPageSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5173);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_authenticationSlice__WEBPACK_IMPORTED_MODULE_1__]);
_authenticationSlice__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const reducers = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.combineReducers)({
    cart: _cartSlice__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP,
    homePageItems: _homePageSlice__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
    authInfo: _authenticationSlice__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
    userInfo: _userPageSlice__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (reducers);

});

/***/ }),

/***/ 5173:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _data_fetch_userPageFetch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2513);


const initialState = {
    authLoading: false,
    authInfo: {}
};
const userInfoSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'userInfoSlice',
    initialState,
    reducers: {},
    extraReducers: {
        [_data_fetch_userPageFetch__WEBPACK_IMPORTED_MODULE_1__/* .userInfo.pending */ .e.pending]: (state)=>{
            state.authLoading = true;
        },
        [_data_fetch_userPageFetch__WEBPACK_IMPORTED_MODULE_1__/* .userInfo.fulfilled */ .e.fulfilled]: (state, { payload  })=>{
            state.authLoading = false;
            state.authInfo = payload;
        },
        [_data_fetch_userPageFetch__WEBPACK_IMPORTED_MODULE_1__/* .userInfo.rejected */ .e.rejected]: (state)=>{
            state.authLoading = false;
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (userInfoSlice.reducer);


/***/ })

};
;