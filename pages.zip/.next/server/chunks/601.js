"use strict";
exports.id = 601;
exports.ids = [601];
exports.modules = {

/***/ 3796:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/product-1.a603c7b5.png","height":380,"width":318,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAMAAAAC2hU0AAAAclBMVEX5+fn4+Pj8///6/v76/v37/f37/fz6/Pz7+/z5+/v5+vr5+vn6+fr5+fr5+fn3+vn5+Pn4+Pj49/f39/fw9vPz8O707u3r6+fo2NrmxcfaxcTkubz3rp7VtLnZqqXWpaDanp7LkovlhWfjZFfZW1XCAAAb3jKVAAAAAnRSTlP5+XeM3XQAAAA/SURBVHjaBUCFEYAwDPwWDxD44O77r8jBKUl1UGZpYQqW/dB6QoL1viZBszzvdybojn3exhwSVpGPCcfazPADdGoDr/h9SXwAAAAASUVORK5CYII="});

/***/ }),

/***/ 4057:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8768);
/* harmony import */ var _heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _heroicons_react_solid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1143);
/* harmony import */ var _heroicons_react_solid__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_solid__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_pure_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3611);
/* harmony import */ var react_pure_modal__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_pure_modal__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _hook_LocalStorageHelper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4173);
/* harmony import */ var _hook_useCartHook__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2656);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hook_LocalStorageHelper__WEBPACK_IMPORTED_MODULE_6__]);
_hook_LocalStorageHelper__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

/* eslint-disable react/jsx-no-duplicate-props */ /* eslint-disable @next/next/no-img-element */ /* eslint-disable react/jsx-key */ 







const ModalComponent = ({ modal , setModal , modalProductInfo  })=>{
    const productItemId = modalProductInfo?.id;
    const productImageParse = modalProductInfo?.image ? JSON.parse(modalProductInfo?.image) : "";
    const productImage = "http://laravelapi.kamruzzaman.xyz/" + productImageParse[0];
    const { 0: defaultImage , 1: setdefaultImage  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    const { 0: productId , 1: setProductId  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(modalProductInfo ? modalProductInfo.id : "");
    const { cartQuantity , addItemToCart , increaseProduct , decrementProduct  } = (0,_hook_useCartHook__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(productId);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    //console.log("modla qunatity", productImageParse)
    const productInfo = {
        id: productItemId,
        title: modalProductInfo?.name,
        price: modalProductInfo?.actual_price,
        detail: "lorem",
        image: productImage
    };
    const addProduct = ()=>{
        addItemToCart(productInfo);
    };
    const incriment = ()=>{
        increaseProduct(productId);
    };
    const dicrement = ()=>{
        decrementProduct(productId);
    };
    const urlSaveIfNotLogin = ()=>{
        let urlLocation = window.location;
        _hook_LocalStorageHelper__WEBPACK_IMPORTED_MODULE_6__/* ["default"].SetRedirectFromDetails */ .Z.SetRedirectFromDetails(urlLocation);
        let loginStatus = _hook_LocalStorageHelper__WEBPACK_IMPORTED_MODULE_6__/* ["default"].userLoginStatus */ .Z.userLoginStatus();
        if (loginStatus) {
            router.push('/cart');
        } else {
            router.push('/login');
        }
    };
    function toggleModal(e) {
        setIsOpen(!isOpen);
    }
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        setProductId(productItemId ? productItemId : "");
    });
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        setdefaultImage(productImage);
    }, [
        modalProductInfo
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_pure_modal__WEBPACK_IMPORTED_MODULE_5___default()), {
            isOpen: modal,
            width: "800px",
            onClose: ()=>{
                setModal(false);
                return true;
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex relative p-2 panel-body ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "absolute right-0",
                        children: [
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                onClick: ()=>setModal(false)
                            }),
                            " "
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-1/2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: defaultImage,
                                    alt: "",
                                    className: "w-[500px] h-[500px]"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex items-center cursor-pointer",
                                children: productImageParse.length > 0 ? productImageParse?.map((image, index)=>{
                                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "http://laravelapi.kamruzzaman.xyz/" + image,
                                        alt: "",
                                        className: "w-28 h-28 mr-1 mt-1",
                                        onClick: ()=>setdefaultImage("http://laravelapi.kamruzzaman.xyz/" + image)
                                    }));
                                }) : "dd"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-1/2 ml-7",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-xs text-gray-400 mr-5",
                                        children: "STATUS"
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-xs bs-dark-green-color font-medium",
                                        children: "In Stock"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "mt-3 text-gray-900 font-medium",
                                        children: modalProductInfo?.name
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center",
                                        children: [
                                            Array(5).fill().map((_, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_solid__WEBPACK_IMPORTED_MODULE_2__.StarIcon, {
                                                    className: "h-4 text-orange-300"
                                                })
                                            ),
                                            "\xa0 \xa0 ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-xs text-gray-400",
                                                children: "10 reviews"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mt-5",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "font-bold text-xl mr-3",
                                        children: [
                                            "$",
                                            modalProductInfo?.actual_price
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("del", {
                                        className: "text-gray-400 mr-3",
                                        children: [
                                            "$ ",
                                            modalProductInfo?.discount_price
                                        ]
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-xs text-gray-400",
                                        children: "(+15% vat included)"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-sm mt-2",
                                        children: "20 Products sold in last 12 hours"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                className: "my-5"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "my-2",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center text-4xl mb-5 justify-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-xs mr-1",
                                            children: "QUANTITY"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: `${cartQuantity && cartQuantity !== 0 ? "" : "hidden"} h-10 w-10 border border-gray-900 rounded-full ml-2`,
                                            onClick: dicrement,
                                            children: " - "
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "h-10 w-10 border rounded-full bg-gray-300 mx-2 text-center text-2xl font-medium leading-9",
                                            children: [
                                                " ",
                                                cartQuantity,
                                                " "
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: `${cartQuantity && cartQuantity !== 0 ? "" : "hidden"} h-10 w-10 border border-gray-900 rounded-full mr-2`,
                                            onClick: incriment,
                                            children: " + "
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "text-xs text-gray-400",
                                            children: [
                                                "Only ",
                                                modalProductInfo?.quantity,
                                                "  items left"
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "w-full h-12 bs-dark-green-bg text-white rounded-3xl mb-3",
                                        onClick: addProduct,
                                        children: "Add To Cart"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "w-full h-12 bg-gray-300 text-black rounded-3xl",
                                        onClick: urlSaveIfNotLogin,
                                        children: "Buy Now"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between text-xs my-3 mx-2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1__.HeartIcon, {
                                                className: "h-6 mr-1"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "cursor-pointer",
                                                children: "Add To Wishlist"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1__.SwitchHorizontalIcon, {
                                                className: "h-6 mr-1"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "cursor-pointer",
                                                children: "Add To Compare"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1__.ShareIcon, {
                                                className: "h-6 mr-1"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "cursor-pointer",
                                                children: "Share"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                className: "my-2"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                    className: "table-auto",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "pr-5 text-left text-gray-400 text-sm",
                                                    children: "SKU"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    className: "text-xs font-semibold",
                                                    children: "KE-008819"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "pr-5 text-left text-gray-400 text-sm",
                                                    children: "CATEGORY"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    className: "text-xs font-semibold",
                                                    children: "Food"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "pr-5 text-left text-gray-400 text-sm",
                                                    children: "TAGS"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    className: "text-xs font-semibold",
                                                    children: "Food, Fruits, Vegetables"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModalComponent);

});

/***/ })

};
;