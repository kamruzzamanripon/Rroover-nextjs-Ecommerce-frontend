"use strict";
exports.id = 656;
exports.ids = [656];
exports.modules = {

/***/ 2656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5808);



const useCartHook = (id1)=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const { 0: cartQuantity , 1: setCartQuantity  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const cartItems = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)(_store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_2__/* .selectItems */ .a1);
    const Total = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)(_store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_2__/* .selectTotal */ .mS);
    //console.log("cart hook",cartQuantity )
    //console.log(cartItems, getCart )
    const addItemToCart = (productInfo)=>{
        dispatch((0,_store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_2__/* .addToCart */ .Xq)(productInfo));
    };
    const increaseProduct = (id)=>{
        dispatch((0,_store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_2__/* .incrementQuantity */ .g1)(id));
    };
    const decrementProduct = (id)=>{
        setCartQuantity(cartQuantity - 1);
        dispatch((0,_store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_2__/* .decrementQuantity */ .X1)(id));
    };
    const deleteProduct = (id)=>{
        setCartQuantity(0);
        dispatch((0,_store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_2__/* .removeFromCart */ .h2)(id));
    //console.log('Delete cart hook', cartQuantity)
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        cartItems.map((item, index)=>{
            if (id1 === item.id) {
                setCartQuantity(item.quantity);
            }
        });
        const itemIndex = cartItems.findIndex((item)=>item.id === id1
        );
        if (itemIndex < 0) {
            setCartQuantity(0);
        }
    }, [
        cartItems,
        id1
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        dispatch((0,_store_slices_cartSlice__WEBPACK_IMPORTED_MODULE_2__/* .getCart */ .dv)());
    }, []);
    return {
        cartQuantity,
        cartItems,
        Total,
        addItemToCart,
        increaseProduct,
        decrementProduct,
        deleteProduct
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useCartHook);


/***/ })

};
;