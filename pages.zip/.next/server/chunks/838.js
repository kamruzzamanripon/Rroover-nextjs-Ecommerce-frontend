"use strict";
exports.id = 838;
exports.ids = [838];
exports.modules = {

/***/ 1927:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/heart.64876a08.png","height":24,"width":24,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAWUlEQVR42j2HuwmAQBBEBzsx10qEmdxfahsa6fVwoKBmV6S73OFbeLMPDmugq9w5g24+fM27Z68DUKvGHDhCEzcUuGqw0aUFvotOZJQ026UclZuR8S+ajPJ92BEXO2bXmYMAAAAASUVORK5CYII="});

/***/ }),

/***/ 5630:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/search.cfaaf2b3.png","height":24,"width":24,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAcElEQVR42mPwY2Zg8Ff1a/Fr8VdmYPAH8hj81P23+AX5hfht8tNiAAG/Cf72YNrWbxJYwH+mvwxYQMZ/OkQg1G++H68fm99av1iQOCMDg3+q31K/mf7dfqt85WBCjD4sDAz+QX5FEGOZwSQrAwMDAwAsihjOSj02uQAAAABJRU5ErkJggg=="});

/***/ }),

/***/ 5957:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ common_Logo)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/logo.png
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.d0a30340.png","height":61,"width":65,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA+UlEQVR42mOAgf9HS5Pmtkflr+lxqvu5za2ib7/X4QUnk6oZYhZ72zFMVzd+vD2/79ux5JX/Npite9vs/XHe/uA7044nnGIIWuTpwzDXOXLxmsCtfxdGnL3Qlro7elv06/z17teS1vgkMcBA2krXyu8z/a6/KnP5ufCm+v/2I04HrBYWWTLYLvJgBatY6pF+fq5319UK+4ttR5wulu1JPBWxttCGwWGhOxNI3n2huy3DYo9KhqVuDcbzwybGb8qvTdmcNRms2XmRByOIDljo7hS8wMPbZbGTj9Nij16/FeFtYAX2Cz1YILT7YiAudFjkqQMUO8vAwMAAAO+jZ6pm9fAuAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/common/Logo.js





const Logo = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
        href: "/",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
            className: "sm:flex text-xs text-center sm:font-size-32 font-medium items-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "mr-2",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                        src: logo
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: " text-xl ml-5 sm:text-4xl ",
                    children: "Bengal Shop"
                })
            ]
        })
    }));
};
/* harmony default export */ const common_Logo = (Logo);


/***/ }),

/***/ 5710:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout_Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@heroicons/react/outline"
var outline_ = __webpack_require__(8768);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/images/010-call-center 5.png
/* harmony default export */ const _010_call_center_5 = ({"src":"/_next/static/media/010-call-center 5.fed6221f.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAdVBMVEXr+uvr+evq+erv/O/u/O7u++3t++3q+er0//Pz//Lv/O7t++3t++zr+uvq+ern+Ojn9+fl9+bl9ube8+Db8d7V7tnU7djU7dfR69XN6dLL6dDL6NDJ58/H583G5szF5cvE5crC5MnA48e94cS84cS84cOp17Tbb4uDAAAACHRSTlPm5ub+/v7+/qzo168AAABKSURBVHjaFctbFkAgFAXQg8rj5qKQhLznP0TL/t9IWBojGWDtwuw0Q1hflN4KUFyGfo2Ebj/f+9gM1Di1zRMyMFF1Rfpbzqzq9AOb5QRdatlPfQAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/images/010-call-center 6.png
/* harmony default export */ const _010_call_center_6 = ({"src":"/_next/static/media/010-call-center 6.cdb10b8f.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAVFBMVEXq+erw/e/t++zs+uzo+Oju++3t++3t++zr+uvq+ero+Ojl9+bi9ePg8+Hf8+Hd8t/T7dfS7dbQ69XK6dDK6M/H583F5cvC5Mm+4sW94cS438G438Du7gZbAAAABXRSTlPm/v7+/mwmGKgAAABASURBVHjaBUCHEYAgDHypofcAuv+eHmAerR8DUOJ7ORHUXuesrUDcem9MsGF87wgWItacaxQgP0uZngCSzknCD3PBAxyL7yhrAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/images/010-call-center 7.png
/* harmony default export */ const _010_call_center_7 = ({"src":"/_next/static/media/010-call-center 7.36568825.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAhFBMVEXr+uvq+eru/O7t++3s++zs+uzs+uvr+uvo+Oju/O7u++3t++3s+uzr+uvq+ero+Ojm9+bj9eTg9OLZ8NzW7tnU7djU7dfT7dfR7NXR69XQ69XQ69TO6tLM6dHL6NDK6M/I583H5s3H5szG5szF5cvC48jA48e+4cW94cW438C23r+03b0Hw9n/AAAACXRSTlPm5v7+/v7+/v6a87SRAAAASElEQVR42gVABxJAMBBcoid3iBIleuf//zNwSCQyZIDY1DpVDC+/363IAnC8TLuuJHi47FfOCtHRjc+5+qDWmr4hAqRLJMj5AaPBBLFX1YxdAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/images/010-call-center8.png
/* harmony default export */ const _010_call_center8 = ({"src":"/_next/static/media/010-call-center8.fc584c62.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAPFBMVEXr+uvs+uvr+uvv/O7u/O7u++3s+uzq+ero+Ojn+Ojd8t/b8d3Z8NvW7tnV7tnR7NXL6NDH583H5s2/4saJHllAAAAAA3RSTlPm/v6HI3vkAAAAPklEQVR42hXLxwEAIAgEwRNRDGDsv1fxvbOAUIokgOSiVrIg1LN01wC2fmcbDB5t3m7saes6nhybfux7TCR4SxgCFehmie4AAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./public/images/Frame 1171274604.png
/* harmony default export */ const Frame_1171274604 = ({"src":"/_next/static/media/Frame 1171274604.912fa4d6.png","height":27,"width":344,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAK0lEQVR4nGNUCepLumNodDPu4623N3beNTv3cs/jP6/Oci3raHu08fwzMQA+dRRfeUz08wAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/layout/sort/FooterBottom.js




const FooterBottom = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-gray-200 py-10",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-wrap justify-between items-center text-center mx-16 sm:flex-nowrap sm:mx-0 items-center ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full sm:w-1/3"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full sm:w-1/3 text-center",
                        children: "@2022 Copyright All Right Reserved by Bengal Shop"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full sm:w-1/3 text-right",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                            src: Frame_1171274604
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const sort_FooterBottom = (FooterBottom);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./public/images/Apple badge.png
/* harmony default export */ const Apple_badge = ({"src":"/_next/static/media/Apple badge.d412ad69.png","height":47,"width":141,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAQAAAAEwYbDAAAAPElEQVR42mMw/+bx3+6/03+v/7b/LP5rv2eY/f/i/6T/Lf8rgbj6v+9vhoSvDf8j/tb+i/uX9Tf3f8BbAC8nIOPsmIXoAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/images/Play store badge.png
/* harmony default export */ const Play_store_badge = ({"src":"/_next/static/media/Play store badge.ec26a906.png","height":48,"width":159,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAATUlEQVR4nGNUqu/8YMp0n4vtzIN/bBJyDL9+fGd48+YNAxMTE8OzZ8/+MbqVdX3X+3mX49WLFwwiMqoMfLw8DB8/fmTg4OBgePz48X8A2lAdnpgHux0AAAAASUVORK5CYII="});
// EXTERNAL MODULE: ./components/common/Logo.js + 1 modules
var Logo = __webpack_require__(5957);
;// CONCATENATED MODULE: ./components/layout/sort/FooterMiddle.js








const FooterMiddle = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-gray-200 py-10",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-center sm:text-left sm:flex items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full sm:w-3/5 pr-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Logo/* default */.Z, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "my-8",
                                children: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid culpa voluptatum consequuntur harum aliquam. Ab odio doloremque tempore perspiciatis corrupti dicta minima iure aliquid obcaecati?"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: "mr-4",
                                        href: "",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                            src: Play_store_badge
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                            src: Apple_badge
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full sm:w-1/5 pl-6",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "text-2xl mb-6",
                                children: "About Us"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "leading-loose",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: "About Karte"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: "Contact"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: "Career"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: "Terms & Conditions"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: "Category"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full sm:w-1/5 pl-6",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "text-2xl mb-6",
                                children: "About Us"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "leading-loose",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: "About Karte"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: "Contact"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: "Career"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: "Terms & Conditions"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: "Category"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const sort_FooterMiddle = (FooterMiddle);

;// CONCATENATED MODULE: ./components/layout/sort/FooterTop.js








const FooterTop = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "container my-20",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "sm:flex -mx-4 mb-10",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-center mx-10 px-4 flex items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "min-w-max mr-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    src: _010_call_center_5
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-xl font-medium mb-2",
                                        children: "24 Customer Support"
                                    }),
                                    " ",
                                    "Contact us 24 hours"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-center mx-10 px-4 flex items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "min-w-max mr-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    src: _010_call_center_6
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-xl font-medium mb-2",
                                        children: "Authentic Products"
                                    }),
                                    " ",
                                    "Contact us 24 hours"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-center mx-10 px-4 flex items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "min-w-max mr-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    src: _010_call_center_7
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-xl font-medium mb-2",
                                        children: "Secure Payment"
                                    }),
                                    " ",
                                    "Contact us 24 hours"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-center mx-10 px-4 flex items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "min-w-max mr-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    src: _010_call_center8
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-xl font-medium mb-2",
                                        children: "Best Prices & Offers"
                                    }),
                                    " ",
                                    "Contact us 24 hours"
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const sort_FooterTop = (FooterTop);

;// CONCATENATED MODULE: ./components/layout/Footer.js











const Footer = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(sort_FooterTop, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(sort_FooterMiddle, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(sort_FooterBottom, {})
        ]
    }));
};
/* harmony default export */ const layout_Footer = (Footer);


/***/ }),

/***/ 9864:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sort_HeaderBottom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5305);
/* harmony import */ var _sort_HeaderTop__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(340);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_sort_HeaderTop__WEBPACK_IMPORTED_MODULE_3__]);
_sort_HeaderTop__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const Header = ()=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sort_HeaderTop__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sort_HeaderBottom__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

});

/***/ }),

/***/ 838:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5710);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9864);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Header__WEBPACK_IMPORTED_MODULE_4__]);
_Header__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const Layout = ({ children , title ="Ecommerce"  })=>{
    //console.log("layout", title)
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Footer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

});

/***/ }),

/***/ 3885:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hook_LocalStorageHelper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4173);
/* harmony import */ var _store_slices_data_fetch_userPageFetch__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2513);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hook_LocalStorageHelper__WEBPACK_IMPORTED_MODULE_4__]);
_hook_LocalStorageHelper__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];






const Account = ()=>{
    const userallInfo = _hook_LocalStorageHelper__WEBPACK_IMPORTED_MODULE_4__/* ["default"].userInfo */ .Z.userInfo();
    const userInfoParse = userallInfo ? JSON.parse(userallInfo) : '';
    const userId = userInfoParse.id;
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        dispatch((0,_store_slices_data_fetch_userPageFetch__WEBPACK_IMPORTED_MODULE_5__/* .userInfo */ .e)(userId));
    }, []);
    //console.log("Header account page", userInfoParse)
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
        href: "/user",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            className: "flex items-center",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: "Account"
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Account);

});

/***/ }),

/***/ 5305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ sort_HeaderBottom)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: ./public/images/chevron-down.png
/* harmony default export */ const chevron_down = ({"src":"/_next/static/media/chevron-down.e4e9918d.png","height":25,"width":30,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAQAAACfUMTVAAAARklEQVR42k2LsQ2AMBDEnI8YAXo2oGEIpmEBOiqWtpBeSZTKPksHWAwwLACYcGE4nh7g5d6Sm5+3rzVDYvWZLwFjdrV2/wFvJRzbQWxjNwAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/images/menu-right.png
/* harmony default export */ const menu_right = ({"src":"/_next/static/media/menu-right.830744af.png","height":25,"width":37,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAQAAADSmGXeAAAAPklEQVR42kXIMQ5AQBAAwD3RSVSiUonKM/Q01yqJ/39gopBzU058TBazJgqHy2n8yybLHmuJ3W2ISqfXStILIHcZvVMSbtoAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./public/images/u_percentage.png
/* harmony default export */ const u_percentage = ({"src":"/_next/static/media/u_percentage.f9183036.png","height":24,"width":24,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAS1BMVEX+XAD+WwD+WgD+XAD+WwD+WwD+WwD+XQD+WgD+XAD+WQD+XAD+WwD+WwD+WgD+WwD+WwD+WwD+XAD+WwD+XAD+WwD+WwD+WwD+WwCidWZCAAAAGXRSTlMAAAABAQIECgoaGhwcNDRVWWhtbW9vuM7x6E1SEgAAAEFJREFUeNody0kSgCAQBMEuFRRkGVyA/7/UCPOeWgUenLRbIjeEzTeMgkh37REvT+j1OiXyiM80RCskOxa5fy/bB06rAjMZj7YxAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/layout/sort/HeaderBottom.js

/* eslint-disable react-hooks/exhaustive-deps */ 






const HeaderBottom = ()=>{
    const { 0: allCategoryMenu , 1: setAllCategoryMenu  } = (0,external_react_.useState)(false);
    const { categoryItems  } = (0,external_react_redux_.useSelector)((state)=>state.homePageItems?.categories
    );
    const categoryLoading = (0,external_react_redux_.useSelector)((state)=>state.homePageItems?.categories?.categoryLoading
    );
    //console.log("categoryData", categoryItems)
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "mb-10",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: " flex items-center ",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-10 mr-5 sm:w-96 relative",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bs-dark-green-bg flex rounded-full px-4 cursor-pointer py-2 relative z-20",
                            onClick: ()=>setAllCategoryMenu(!allCategoryMenu)
                            ,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "-ml-5 sm:ml-0 min-w-max",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                            src: menu_right
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "hidden sm:block w-full text-center px-6 text-white",
                                    children: "All Caterories"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "min-w-max",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                            src: chevron_down
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `${allCategoryMenu ? "blog visible" : "hidden invisible"} absolute w-100% whitespace-nowrap px-5 sm:w-full bs-dark-green-bg z-10 -mt-5 pt-6 pb-4 rounded-b-2xl`,
                            children: !categoryLoading && /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                children: categoryItems.length > 0 && categoryItems.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "block text-white py-2 px-4 transition ease-out duration-100 hover:text-gray-700 hover:font-bold",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: `/category/${item.id}`,
                                            children: item.name
                                        })
                                    }, index)
                                )
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "sm:w-full",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "flex justify-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "p-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/",
                                    children: "Home"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "hidden sm:block p-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/about",
                                    children: "About"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "hidden sm:block p-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/",
                                    children: "Contact"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "hidden sm:block p-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/",
                                    children: "FAQs"
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                    href: "/",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "min-w-max bs-dark-orange-color flex items-center cursor-pointer",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                src: u_percentage
                            }),
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "mr-3",
                                children: "Special Offers!"
                            })
                        ]
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const sort_HeaderBottom = (HeaderBottom);


/***/ }),

/***/ 340:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9915);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8922);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_hot_toast__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _public_images_heart_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1927);
/* harmony import */ var _public_images_search_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5630);
/* harmony import */ var _common_Logo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5957);
/* harmony import */ var _Account__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3885);
/* harmony import */ var _LogOut__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4174);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_LogOut__WEBPACK_IMPORTED_MODULE_10__, _Account__WEBPACK_IMPORTED_MODULE_9__, js_cookie__WEBPACK_IMPORTED_MODULE_1__]);
([_LogOut__WEBPACK_IMPORTED_MODULE_10__, _Account__WEBPACK_IMPORTED_MODULE_9__, js_cookie__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);











const HeaderTop = ()=>{
    const { 0: token , 1: setToken  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const { 0: tokenStatus , 1: setTokenStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(true);
    const Cookiestoken = js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get('passport_frontend') ? js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get('passport_frontend') : '';
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        if (Cookiestoken && Cookiestoken.length > 1) {
            setToken(true);
        }
    }, [
        token,
        setToken,
        Cookiestoken
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        if (tokenStatus === false) {
            setToken(false);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5___default()("Successfully Log Out.");
        }
    });
    //console.log("headers", token)
    //console.log("headers22", tokenStatus, token)
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex justify-between items-center py-6",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.Toaster, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Logo__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-96 hidden sm:block",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "border border-gray-100 p-1 flex rounded-full items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "min-w-max px-3",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                src: _public_images_search_png__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            className: "w-full px-3 py-1 focus:outline-none",
                            type: "search",
                            placeholder: "Search here...."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "bg-gray-600 bs-button-bg px-6 rounded-full py-2 text-white",
                            type: "submit",
                            children: "Search"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "min-w-max flex items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                        href: "/wishlist",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            className: "bs-icon-box rounded-full hover:bg-gray-200 inline-block flex items-center justify-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                src: _public_images_heart_png__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                                alt: ""
                            })
                        })
                    }),
                    token ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Account__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LogOut__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                setTokenStatus: setTokenStatus
                            })
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                href: "/login",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "flex items-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Login"
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: " / "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                href: "/register",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "flex items-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Register"
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderTop);

});

/***/ }),

/***/ 4174:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_slices_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_slices_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_4__]);
_store_slices_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const LogOut = ({ setTokenStatus  })=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const logOutuser = ()=>{
        setTokenStatus(false);
        dispatch((0,_store_slices_data_fetch_authenticationDataFetch__WEBPACK_IMPORTED_MODULE_4__/* .logout */ .kS)());
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            className: "flex items-center cursor-pointer pl-5",
            onClick: ()=>logOutuser()
            ,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: "Logout"
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LogOut);

});

/***/ }),

/***/ 4173:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_0__]);
js_cookie__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

class LocalStorageHelper {
    static SetRedirectFromDetails(urlLocation) {
        sessionStorage.setItem("urlLocation", urlLocation);
    }
    static GetRedirectFromDetails() {
        return sessionStorage.getItem("urlLocation");
    }
    static userLoginStatus() {
        return js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].get('passport_frontend');
    }
    static userInfo() {
        return js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].get('user_info');
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LocalStorageHelper);

});

/***/ })

};
;