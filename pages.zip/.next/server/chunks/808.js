"use strict";
exports.id = 808;
exports.ids = [808];
exports.modules = {

/***/ 5808:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Xq": () => (/* binding */ addToCart),
/* harmony export */   "h2": () => (/* binding */ removeFromCart),
/* harmony export */   "g1": () => (/* binding */ incrementQuantity),
/* harmony export */   "X1": () => (/* binding */ decrementQuantity),
/* harmony export */   "dv": () => (/* binding */ getCart),
/* harmony export */   "a1": () => (/* binding */ selectItems),
/* harmony export */   "mS": () => (/* binding */ selectTotal),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    items: []
};
const cartSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "cart",
    initialState,
    reducers: {
        getCart: (state, action)=>{
            if (localStorage && localStorage.getItem('cart')) {
                state.items = JSON.parse(localStorage.getItem('cart'));
            } else {
                state.items = [];
            }
        },
        addToCart: (state, action)=>{
            const itemExists = state.items.find((item)=>item.id === action.payload.id
            );
            if (itemExists) {
                itemExists.quantity++;
            } else {
                state.items = [
                    ...state.items,
                    {
                        ...action.payload,
                        quantity: 1
                    }
                ];
            }
            localStorage.setItem('cart', JSON.stringify(state.items));
        },
        incrementQuantity: (state, action)=>{
            const item1 = state.items.find((item)=>item.id === action.payload
            );
            item1.quantity++;
            localStorage.setItem('cart', JSON.stringify(state.items));
        },
        decrementQuantity: (state, action)=>{
            const item2 = state.items.find((item)=>item.id === action.payload
            );
            if (item2.quantity === 1) {
                const index = state.items.findIndex((item)=>item.id === action.payload
                );
                state.items.splice(index, 1);
            } else {
                item2.quantity--;
            }
            localStorage.setItem('cart', JSON.stringify(state.items));
        },
        removeFromCart: (state, action)=>{
            const index = state.items.findIndex((item)=>item.id === action.payload
            );
            let newCart = [
                ...state.items
            ];
            if (index >= 0) {
                newCart.splice(index, 1);
            } else {
                console.warn(`can't remove product (id: ${action.payload.id}) as is not in the cart`);
            }
            state.items = newCart;
            localStorage.setItem('cart', JSON.stringify(state.items));
        }
    }
});
const { addToCart , removeFromCart , incrementQuantity , decrementQuantity , getCart  } = cartSlice.actions;
//Selectors- this is how we pull information from the global store slice
const selectItems = (state)=>state.cart.items
;
const selectTotal = (state)=>state.cart.items.reduce((total, item)=>total + item.price * item.quantity
    , 0)
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cartSlice.reducer);


/***/ })

};
;