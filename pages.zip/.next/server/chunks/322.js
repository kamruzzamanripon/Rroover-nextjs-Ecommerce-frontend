"use strict";
exports.id = 322;
exports.ids = [322];
exports.modules = {

/***/ 16:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ axios_auth_header)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_1__);


function axios_auth_header(ctx) {
    //console.log("useAxios_authheaders", ctx)
    //console.log("useAxios_authheaders", parseCookies(ctx))
    const { passport_frontend  } = (0,nookies__WEBPACK_IMPORTED_MODULE_1__.parseCookies)(ctx) ? (0,nookies__WEBPACK_IMPORTED_MODULE_1__.parseCookies)(ctx) : "";
    const token = passport_frontend ? passport_frontend : "";
    const api = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
        withCredentials: true,
        headers: {
            'Authorization': `Bearer ${token}`
        }
    });
    return api;
//api.defaults.headers.common['Authorization'] = `Bearer ${snactum_frontend}`;
};


/***/ }),

/***/ 7495:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "x4": () => (/* binding */ login),
/* harmony export */   "kS": () => (/* binding */ logout),
/* harmony export */   "l9": () => (/* binding */ registration),
/* harmony export */   "o9": () => (/* binding */ forgetPassword),
/* harmony export */   "oh": () => (/* binding */ forgetPasswordReset)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9915);
/* harmony import */ var _hook_useAxios_auth_header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_2__]);
js_cookie__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const login = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('authenticationSlice/login', async (data)=>{
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`${"http://laravelapi.kamruzzaman.xyz/api/v1/frontend"}/user-login/`, data);
        if (res.data.token_info) {
            const token = res.data.token_info.token;
            const user_info = res.data.token_info;
            js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].set("passport_frontend", token);
            js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].set("user_info", JSON.stringify(user_info));
            (axios__WEBPACK_IMPORTED_MODULE_1___default().defaults.headers.common.Authorization) = `Bearer ${token}`;
        //console.log("token", res.data)
        }
        //console.log("token", res)
        return res.data;
    } catch (e) {
        //console.log("login usere ERror",e.response)
        return e.response;
    }
});
const logout = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('authenticationSlice/logout', async (ctx)=>{
    try {
        const res = await (0,_hook_useAxios_auth_header__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(ctx).post(`${"http://laravelapi.kamruzzaman.xyz/api/v1/frontend"}/user-logout`);
        js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].remove('passport_frontend');
        js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].remove('user_info');
        console.log("axios logout", res);
        return res.data;
    } catch (e) {
        console.log(e.response);
    }
});
const registration = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('authenticationSlice/registration', async (data)=>{
    try {
        //console.log('axios registration page', data)
        const res = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`${"http://laravelapi.kamruzzaman.xyz/api/v1/frontend"}/user-register/`, data);
        return res.data;
    } catch (e) {
        //console.log("login usere ERror",e.response)
        return e.response;
    }
});
const forgetPassword = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('authenticationSlice/forgetpassword', async (data)=>{
    try {
        //console.log('axios registration page', data)
        const res = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`${"http://laravelapi.kamruzzaman.xyz/api/v1/frontend"}/password/forgot-password/`, data);
        console.log('axios forgetpassword', res);
        console.log('axios forgetpassword', res.data);
        return res.data;
    } catch (e) {
        //console.log("login usere ERror",e.response)
        return e.response;
    }
});
const forgetPasswordReset = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('authenticationSlice/forgetpasswordreset', async (data)=>{
    try {
        //console.log('axios registration page', data)
        const res = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`${"http://laravelapi.kamruzzaman.xyz/api/v1/frontend"}/password/reset/`, data);
        console.log('axios forgetpassword', res);
        console.log('axios forgetpassword', res.data);
        return res.data;
    } catch (e) {
        //console.log("login usere ERror",e.response)
        return e.response;
    }
});

});

/***/ }),

/***/ 2513:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ userInfo)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hook_useAxios_auth_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16);


const userInfo = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('userInfoSlice/unserInfo', async (userId, ctx)=>{
    try {
        const res = await (0,_hook_useAxios_auth_header__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(ctx).get(`${"http://laravelapi.kamruzzaman.xyz/api/v1/frontend"}/check-out/userinfo/${userId}`);
        console.log("axios account info", res.data.data);
        return res.data.data;
    } catch (e) {
        //console.log(e.response);
        return e.response.data.message;
    }
});


/***/ })

};
;