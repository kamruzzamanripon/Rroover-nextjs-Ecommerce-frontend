"use strict";
(() => {
var exports = {};
exports.id = 737;
exports.ids = [737];
exports.modules = {

/***/ 595:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_WishList)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@heroicons/react/solid"
var solid_ = __webpack_require__(1143);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/images/product-2.png
/* harmony default export */ const product_2 = ({"src":"/_next/static/media/product-2.115441f3.png","height":600,"width":600,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAA00lEQVR42gHIADf/APn5/ebo6ejt7+3n6dTX19zd3dzf2MrQxwDL0cXn5uf24dbwqpLKr6zf5ObZ4txrhEAA0N7T8PL0+6qW+LCJx2NS3uDg1rm0oaCAAPfIye63sebAu+6XjdO7t9iLhO0AAM9gRwDwXj/sUQDDlIzmxMLcr6rQiYLQRzXDdmkA4a+m7JWRz6ej62JG3yoAun93zaKd183LAM3a0NPc1ufo6O2Yk9mQh9VlWfGfedu5pAD29vjT19Du8PHy8/Xt8/Tuurbsk3rhu7JTXIzFlgIvYQAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./components/WishList.js






const WishList = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "container mx-auto px-4 sm:px-8",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "py-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-2xl font-semibold leading-tight",
                            children: "Cart Details"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "-mx-4 sm:-mx-8 px-4 sm:px-8 py-4 overflow-x-auto ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "inline-block min-w-full shadow-md rounded-lg overflow-hidden",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                                className: "min-w-full leading-normal",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider",
                                                    children: "No."
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider",
                                                    children: "Image"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider",
                                                    children: "Product Info"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider",
                                                    children: "Price"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider",
                                                    children: "Quantity"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider",
                                                    children: "Total"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                    className: "px-5 py-5 border-b border-gray-200 bg-white text-base",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "bg-green-700 inline-block w-3 h-6 text-center text-white rounded-sm hover:text-red-600 cursor-pointer mr-2",
                                                            children: "X"
                                                        }),
                                                        "01"
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    className: "px-5 py-5 border-b border-gray-200 bg-white text-base",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "flex-shrink-0 w-10 h-10",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                                src: product_2,
                                                                className: "w-full h-full rounded-sm"
                                                            })
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                    className: "px-5 py-5 border-b border-gray-200 bg-white text-base",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "text-gray-900 whitespace-no-wrap",
                                                            children: "Product Sample Name"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "text-gray-600 whitespace-no-wrap",
                                                            children: "Other information"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    className: "px-5 py-5 border-b border-gray-200 bg-white text-base",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "text-gray-900 whitespace-no-wrap",
                                                        children: "$ 250"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    className: "px-5 py-5 border-b border-gray-200 bg-white text-base",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex items-center",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(solid_.PlusIcon, {
                                                                className: "h-6 cursor-pointer"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "text-gray-900 whitespace-no-wrap mx-2",
                                                                children: "04"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(solid_.MinusIcon, {
                                                                className: "h-6 cursor-pointer"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    className: "px-5 py-5 border-b border-gray-200 bg-white text-base",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "text-gray-900 whitespace-no-wrap",
                                                        children: "$ 1000"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-right mt-5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "inline-block text-base font-semibold bg-blue-800 text-white active:bg-black px-5 py-2 rounded-lg mr-1 sm:mr-5",
                            children: "Continue to Shopping"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: "/cart",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "inline-block text-base font-semibold bg-green-700 text-white active:bg-black px-5 py-2 rounded-lg",
                            children: "Going to Cart"
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const components_WishList = (WishList);


/***/ }),

/***/ 9588:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ cart)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_layout_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(838);
/* harmony import */ var _components_WishList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(595);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_Layout__WEBPACK_IMPORTED_MODULE_1__]);
_components_layout_Layout__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];



function cart(props) {
    //console.log("Index",props)
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Layout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        title: "wish list",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_WishList__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
    }));
};

});

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 1143:
/***/ ((module) => {

module.exports = require("@heroicons/react/solid");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3053:
/***/ ((module) => {

module.exports = require("nookies");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8922:
/***/ ((module) => {

module.exports = require("react-hot-toast");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,322,838], () => (__webpack_exec__(9588)));
module.exports = __webpack_exports__;

})();