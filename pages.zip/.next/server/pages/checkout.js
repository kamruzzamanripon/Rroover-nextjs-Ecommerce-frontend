"use strict";
(() => {
var exports = {};
exports.id = 222;
exports.ids = [222];
exports.modules = {

/***/ 4077:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_CheckOut)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/checkout/AlterShippingInfo.js


const AlterShippingInfo = ()=>{
    const { 0: alterShipping , 1: setAlterShipping  } = (0,external_react_.useState)(false);
    //console.log(alterShipping)
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                className: "block mb-1 mt-5 flex justify-between",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            type: "checkbox",
                            className: "cursor-pointer mr-2",
                            onChange: ()=>setAlterShipping(!alterShipping)
                        }),
                        "Alter Shipping"
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${alterShipping ? "block" : "hidden"}`,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                        className: "block mr-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "block text-sm font-medium text-slate-700",
                                children: "Name"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "text",
                                placeholder: "username or email",
                                className: "input-box"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                        className: "block mr-5 my-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "block text-sm font-medium text-slate-700",
                                children: "Email"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "text",
                                placeholder: "email",
                                className: "input-box"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                        className: "block mr-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "block text-sm font-medium text-slate-700",
                                children: "Address"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                placeholder: "Address",
                                className: "input-box"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                        className: "block mr-5 my-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "block text-sm font-medium text-slate-700",
                                children: "Mobile"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "text",
                                placeholder: "Mobile",
                                className: "input-box"
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const checkout_AlterShippingInfo = (AlterShippingInfo);

;// CONCATENATED MODULE: ./components/checkout/UserInfo.js


const UserInfo = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                className: "block mr-5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "block text-sm font-medium text-slate-700",
                        children: "Name"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "text",
                        placeholder: "username or email",
                        className: "mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-sm shadow-sm placeholder-slate-400 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 disabled:bg-slate-50 disabled:text-slate-500 disabled:border-slate-200 disabled:shadow-none invalid:border-pink-500 invalid:text-pink-600 focus:invalid:border-pink-500 focus:invalid:ring-pink-500 "
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                className: "block mr-5 my-5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "block text-sm font-medium text-slate-700",
                        children: "Email"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "text",
                        placeholder: "email",
                        className: "mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-sm shadow-sm placeholder-slate-400 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 disabled:bg-slate-50 disabled:text-slate-500 disabled:border-slate-200 disabled:shadow-none invalid:border-pink-500 invalid:text-pink-600 focus:invalid:border-pink-500 focus:invalid:ring-pink-500 "
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                className: "block mr-5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "block text-sm font-medium text-slate-700",
                        children: "Address"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                        placeholder: "Address",
                        className: "mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-sm shadow-sm placeholder-slate-400 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 disabled:bg-slate-50 disabled:text-slate-500 disabled:border-slate-200 disabled:shadow-none invalid:border-pink-500 invalid:text-pink-600 focus:invalid:border-pink-500 focus:invalid:ring-pink-500 "
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                className: "block mr-5 my-5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "block text-sm font-medium text-slate-700",
                        children: "Mobile"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "text",
                        placeholder: "Mobile",
                        className: "mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-sm shadow-sm placeholder-slate-400 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 disabled:bg-slate-50 disabled:text-slate-500 disabled:border-slate-200 disabled:shadow-none invalid:border-pink-500 invalid:text-pink-600 focus:invalid:border-pink-500 focus:invalid:ring-pink-500 "
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const checkout_UserInfo = (UserInfo);

;// CONCATENATED MODULE: ./components/checkout/LeftSide.js




const LeftSide = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "md:w-2/3 p-2 md:p-0 md:mr-5 md:px-5",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(checkout_UserInfo, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(checkout_AlterShippingInfo, {})
            ]
        })
    }));
};
/* harmony default export */ const checkout_LeftSide = (LeftSide);

// EXTERNAL MODULE: external "@heroicons/react/solid"
var solid_ = __webpack_require__(1143);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./hook/useCartHook.js
var useCartHook = __webpack_require__(2656);
;// CONCATENATED MODULE: ./components/checkout/RightSide.js

/* eslint-disable react/jsx-key */ 



const RightSide = ()=>{
    const { increaseProduct , decrementProduct , deleteProduct , Total , cartItems  } = (0,useCartHook/* default */.Z)();
    const deleteP = (id)=>{
        deleteProduct(id);
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "md:w-1/3 p-2 md:p-0 md:ml-5",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-full",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "font-bold text-lg mb-2 text-center underline",
                    children: "Cart short Information"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    children: [
                        cartItems.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "border p-2 relative mb-1",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(solid_.XCircleIcon, {
                                        className: "h-5 absolute right-1 top-1 cursor-pointer text-gray-400",
                                        onClick: ()=>deleteP(item.id)
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex-shrink-0 w-12 h-12 mr-2",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                    src: item ? "http://laravelapi.kamruzzaman.xyz/" + item.image : "",
                                                    className: "w-full h-full rounded-sm",
                                                    height: 80,
                                                    width: 80
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "text-gray-900 whitespace-no-wrap text-sm",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: item.title
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        children: [
                                                            "Quentity - ",
                                                            item.quantity,
                                                            " x ",
                                                            item.price
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        children: [
                                                            "$ ",
                                                            item.price * item.quantity
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }, index)
                        ),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "border-double border-4 border-green-600 p-2 flex justify-between",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-bold text-lg",
                                    children: "Total"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "font-bold text-lg",
                                    children: [
                                        "$ ",
                                        Total
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "font-bold text-lg mb-2 text-center underline mt-7",
                    children: "Payment Processing"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "border p-2 relative mb-1 bg-gray-500 text-white",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    className: "form-check-input rounded-full h-4 w-4 border border-gray-300 bg-white checked:bg-blue-600 checked:border-blue-600 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain float-left mr-2 cursor-pointer",
                                    type: "radio",
                                    name: "flexRadioDefault",
                                    id: "flexRadioDefault1"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    className: "form-check-label inline-block cursor-pointer ",
                                    htmlFor: "flexRadioDefault1",
                                    children: "Cash On Delivery"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "border p-2 relative mb-1 bg-gray-500 text-white",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    className: "form-check-input rounded-full h-4 w-4 border border-gray-300 bg-white checked:bg-blue-600 checked:border-blue-600 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain float-left mr-2 cursor-pointer",
                                    type: "radio",
                                    name: "flexRadioDefault",
                                    id: "flexRadioDefault2"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    className: "form-check-label inline-block cursor-pointer ",
                                    htmlFor: "flexRadioDefault2",
                                    children: "Paypal"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "border p-2 relative mb-1 bg-gray-500 text-white",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    className: "form-check-input rounded-full h-4 w-4 border border-gray-300 bg-white checked:bg-blue-600 checked:border-blue-600 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain float-left mr-2 cursor-pointer",
                                    type: "radio",
                                    name: "flexRadioDefault",
                                    id: "flexRadioDefault3"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    className: "form-check-label inline-block cursor-pointer ",
                                    htmlFor: "flexRadioDefault3",
                                    children: "Stripe"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "inline-block text-base font-semibold bg-green-700 text-white active:bg-black px-5 py-2 rounded-lg w-full mt-5",
                                children: "Payment Success"
                            })
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const checkout_RightSide = (RightSide);

;// CONCATENATED MODULE: ./components/CheckOut.js

/* eslint-disable react/jsx-key */ 


const CheckOut = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "container",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "md:flex",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(checkout_LeftSide, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(checkout_RightSide, {})
            ]
        })
    }));
};
/* harmony default export */ const components_CheckOut = (CheckOut);


/***/ }),

/***/ 8283:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ checkout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_CheckOut__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4077);
/* harmony import */ var _components_layout_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(838);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_Layout__WEBPACK_IMPORTED_MODULE_2__]);
_components_layout_Layout__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];



function checkout(props) {
    //console.log("Index",props)
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        title: "Home Layout",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CheckOut__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
    }));
};

});

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 1143:
/***/ ((module) => {

module.exports = require("@heroicons/react/solid");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3053:
/***/ ((module) => {

module.exports = require("nookies");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8922:
/***/ ((module) => {

module.exports = require("react-hot-toast");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,322,838,808,656], () => (__webpack_exec__(8283)));
module.exports = __webpack_exports__;

})();