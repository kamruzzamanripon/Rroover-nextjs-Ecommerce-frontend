"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 7758:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export getServerSideProps */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _common_TitleWithBorderBandComponent__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8567);
/* harmony import */ var _home_FeatureComponent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2117);
/* harmony import */ var _slider_CarouselSlider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5993);
/* harmony import */ var _slider_HeroSlider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5611);
/* harmony import */ var _slider_ProductViewCarouselSlider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1787);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_slider_ProductViewCarouselSlider__WEBPACK_IMPORTED_MODULE_8__]);
_slider_ProductViewCarouselSlider__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];











const Home = ()=>{
    const title = "this is home Page";
    const { categoryItems , categoryLoading  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.homePageItems.categories
    );
    const { brandItems , brandLoading  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.homePageItems.brands
    );
    //console.log("categoryData", brandItems)
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: title
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_slider_HeroSlider__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container my-10",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_TitleWithBorderBandComponent__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    title: "Search By Category"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "sm:flex -mx-6 justify-between",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_home_FeatureComponent__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            backGroundImageClass: "promo-bg-1",
                            column: "2"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_home_FeatureComponent__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            backGroundImageClass: "promo-bg-2",
                            column: "2"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container my-10",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_TitleWithBorderBandComponent__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        title: "Deals of the Week"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_slider_ProductViewCarouselSlider__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container my-10",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_TitleWithBorderBandComponent__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        title: "Popular Brands"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_slider_CarouselSlider__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        backgroundColorClass: "",
                        slug: "brands",
                        dataArray: brandItems,
                        loading: brandLoading
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "sm:flex -mx-6 justify-between",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_home_FeatureComponent__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            backGroundImageClass: "promo-bg-3",
                            column: "3"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_home_FeatureComponent__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            backGroundImageClass: "promo-bg-4",
                            column: "3"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_home_FeatureComponent__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            backGroundImageClass: "promo-bg-5",
                            column: "3"
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);
async function getServerSideProps() {}

});

/***/ }),

/***/ 8567:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const TitleWithBorderBandComponent = ({ title  })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: "text-4xl mb-6",
                children: title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center mb-10",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-32 h-1 bs-dark-green-bg"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-0.5 bg-gray-200"
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TitleWithBorderBandComponent);


/***/ }),

/***/ 2117:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const FeatureComponent = ({ backGroundImageClass , column  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `mb-5 sm:w-1/${column} px-6`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `${backGroundImageClass} promo-bg-1 bg-cover bg-gray-500 bg-right-bottom p-12 bg-center rounded`,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-2/3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "bs-dark-orange-color text-2xl mb-6",
                        children: "Buy 1 Get 1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "font-bold font-size-46 mb-8",
                        children: "Fresh Fruits Collection"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                        href: "/",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            className: "bs-white-btn",
                            children: "Order Now"
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FeatureComponent);


/***/ }),

/***/ 5993:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ slider_CarouselSlider)
});

// UNUSED EXPORTS: getServerSideProps

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
;// CONCATENATED MODULE: ./public/images/002-fashion-1.png
/* harmony default export */ const _002_fashion_1 = ({"src":"/_next/static/media/002-fashion-1.b13f7925.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA40lEQVR42mMAgam5dvzTi+yTtk1JCnm4oyHkhJ9r7nYGRnkGGNg4JZRnTZP/u3NzE/5/Pdbw/2pz5P9FDAzKDCDwaHkME4j+cKDp0Kfd+f/f7In5f2h68LO1DAxcDMjg+fbKq1vrPP6fmWHz//gi03dWDA6CDDDw/xID87llpXfunj76/+qZNf83NjG8X8UQJcSADPZNirtxZnbN/xVTM/83Swm/3Mhgx8MAA0GyciJ9SdbfmjxE/2cy8/7P0TH4787AoMkAAy5cvKISDAwZwgxcObYKChm+aorZLgzs0gwMDAwAmldWKlbYzEQAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./components/slider/CarouselSlider.js

/* eslint-disable react/jsx-key */ 







function SampleNextArrow(props) {
    const { className , style , onClick  } = props;
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: className,
        style: {
            ...style,
            display: "block",
            background: "red",
            top: "-20px",
            right: "3%",
            transform: [
                {
                    rotate: '180deg'
                }
            ]
        },
        onClick: onClick
    }));
}
function SamplePrevArrow(props) {
    const { className , style , onClick  } = props;
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: className,
        style: {
            ...style,
            display: "block",
            background: "green",
            top: "-20px",
            left: "98%"
        },
        onClick: onClick
    }));
}
const CarouselSlider = ({ backgroundColorClass , dataArray , loading , slug  })=>{
    var settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 5,
        slidesToScroll: 5,
        initialSlide: 0,
        nextArrow: /*#__PURE__*/ jsx_runtime_.jsx(SampleNextArrow, {}),
        prevArrow: /*#__PURE__*/ jsx_runtime_.jsx(SamplePrevArrow, {}),
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }, 
        ]
    };
    const dispatch = (0,external_react_redux_.useDispatch)();
    (0,external_react_.useEffect)(()=>{}, [
        dispatch
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
            ...settings,
            children: loading ? "Data Loading" : dataArray?.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                    href: `/${slug}/${item.id}`,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `${backgroundColorClass} p-4 slicker-carousel mr-5 cursor-pointer text-center`,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "h-32 flex justify-center items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    src: item.image ? "http://laravelapi.kamruzzaman.xyz/" + item.image : _002_fashion_1,
                                    width: "85px",
                                    height: "85px"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "text-xl",
                                children: item.name ? item.name : "Groceries"
                            })
                        ]
                    })
                }, index)
            )
        })
    }));
};
/* harmony default export */ const slider_CarouselSlider = (CarouselSlider);
async function getServerSideProps() {}


/***/ }),

/***/ 5611:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ slider_HeroSlider)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
;// CONCATENATED MODULE: ./public/images/hero.png
/* harmony default export */ const hero = ({"src":"/_next/static/media/hero.50f7ce56.png","height":819,"width":661,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAYAAADaxo44AAAAxklEQVR42mMAgf+d25ifO7vfP2Jk0ADinzUyYIFI/P/PemJW56/pmaGTQPyjyUFsDDBwqLfu4q60kK3/GRjkGUDgPwMDDxDf+G9n//+PmfH/t5pK/7/qm7oyvDy+79DrlYv+P5g75+/Jqc2/5tYF/N/WXrSbYe+irP9rNiT8q+yW/L9uQfv/sNr0f4uqnf4zPF/f//v6vvL/O9Zm/b++ofvfxoU9/5dWBd9nuHVq++fTmxf+P7hk4v+tc5r/bJ1e9X/D9PqVAKa4ZQITCXMaAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/slider/HeroSlider.js

/* eslint-disable react/jsx-key */ 







const HeroSlider = ()=>{
    const title = "this is home Page";
    var settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        appendDots: (dots)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    bottom: "8%"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    style: {
                        margin: "0px"
                    },
                    children: dots
                })
            })
    };
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { items , loading  } = (0,external_react_redux_.useSelector)((state)=>state.homePageItems.mainSlider
    );
    //console.log('tiemt' ,items)
    (0,external_react_.useEffect)(()=>{
    //dispatch(mainSliderdata())
    }, [
        dispatch
    ]);
    //console.log(loading)
    return(/*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
            ...settings,
            children: loading ? "Data Loading" : items.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "p-8 ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "slider-bg rounded-2xl relative",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "container",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "w-1/2 mr-6 font-size-22",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "bs-dark-green-color font-size-32 mb-4",
                                                children: "Save up 30% Off"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "text-5xl font-bold mb-6 text-gray-600",
                                                children: item.title
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "mb-8",
                                                children: item.sub_title
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: "bs-button text-base",
                                                    children: "Shop Now"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "w-1/2 flex justify-end text-right",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                            src: item.image ? "http://laravelapi.kamruzzaman.xyz/" + item.image : hero,
                                            width: "661",
                                            height: "819"
                                        })
                                    })
                                ]
                            })
                        })
                    })
                }, index)
            )
        })
    }));
};
/* harmony default export */ const slider_HeroSlider = (HeroSlider);


/***/ }),

/***/ 2973:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _heroicons_react_solid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1143);
/* harmony import */ var _heroicons_react_solid__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_solid__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hook_useCartHook__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2656);
/* harmony import */ var _public_images_product_1_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3796);








const ProductItem = ({ setModal , id , setModalProductInfo , productItemInfo  })=>{
    const productItemId = productItemInfo.id;
    const { addItemToCart , increaseProduct , decrementProduct , cartQuantity  } = (0,_hook_useCartHook__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(productItemId);
    const productImageParse = productItemInfo.image ? JSON.parse(productItemInfo?.image) : "";
    const productImage = productImageParse[0];
    //console.log("home page", productInfo)
    const addItem = ()=>{
        const productInfo = {
            id: productItemId,
            title: productItemInfo?.name,
            price: productItemInfo?.actual_price,
            detail: "lorem",
            image: productImage
        };
        //console.log("productInfo",productcartInfo)
        addItemToCart(productInfo);
    };
    const increment = ()=>{
        increaseProduct(productItemId);
    };
    const decrement = ()=>{
        decrementProduct(productItemId);
    };
    const viewModal = ()=>{
        setModal(true);
        setModalProductInfo(productItemInfo);
    };
    //console.log("image", productImage)
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "category-carousel mb-16 text-center mr-5 group",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "single-bs-product",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "h-100 product-img group relative",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "bg-gray-50 h-full flex justify-center items-center p-4 mb-6",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                src: productImage ? "http://laravelapi.kamruzzaman.xyz/" + productImage : _public_images_product_1_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                width: "318",
                                height: "381",
                                objectFit: "contain"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                            className: "text-xl mb-3",
                            children: productItemInfo?.name
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                            className: "text-xl mb-3",
                            children: "sdfs"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "font-medium bs-dark-orange-color",
                                    children: [
                                        "$",
                                        productItemInfo?.actual_price
                                    ]
                                }),
                                " \xa0",
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("del", {
                                    className: "text-gray-400",
                                    children: [
                                        "$",
                                        productItemInfo?.discount_price
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "product-img-hover absolute h-full w-full top-0 left-0 flex justify-center items-center hidden transition duration-20000 ease-in group-hover:flex",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "bg-black absolute h-full w-full opacity-90"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    className: "absolute left-0 bottom-0 bg-gray-200 p-2 w-full flex items-center justify-center cursor-pointer",
                                    onClick: viewModal,
                                    children: [
                                        "Details",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_solid__WEBPACK_IMPORTED_MODULE_1__.ArrowRightIcon, {
                                            className: "h-5 ml-3 transition group-first:hover:ml-5"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "relative z-10",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-center items-center text-4xl text-white mb-8",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: `${cartQuantity && cartQuantity !== 0 ? "" : "hidden"} h-12 w-12 border border-white rounded-full`,
                                                    onClick: decrement,
                                                    children: " - "
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "px-6",
                                                    children: [
                                                        " ",
                                                        cartQuantity,
                                                        " "
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: `${cartQuantity && cartQuantity !== 0 ? "" : "hidden"} h-12 w-12 border border-white rounded-full`,
                                                    onClick: increment,
                                                    children: " + "
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "bs-dark-green-bg text-white px-8 py-2 rounded-full inline-block",
                                            onClick: addItem,
                                            children: "Add to card"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductItem);


/***/ }),

/***/ 1787:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _common_Modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4057);
/* harmony import */ var _ProductItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2973);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_Modal__WEBPACK_IMPORTED_MODULE_4__]);
_common_Modal__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

/* eslint-disable react/jsx-key */ 






function SampleNextArrow(props) {
    const { className , style , onClick  } = props;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: className,
        style: {
            ...style,
            display: "block",
            background: "red",
            top: "-20px",
            right: "3%",
            transform: [
                {
                    rotate: "180deg"
                }
            ]
        },
        onClick: onClick
    }));
}
function SamplePrevArrow(props) {
    const { className , style , onClick  } = props;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: className,
        style: {
            ...style,
            display: "block",
            background: "green",
            top: "-20px",
            left: "98%"
        },
        onClick: onClick
    }));
}
const ProductViewCarouselSlider = ()=>{
    var settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 5,
        slidesToScroll: 5,
        initialSlide: 0,
        nextArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SampleNextArrow, {}),
        prevArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SamplePrevArrow, {}),
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }, 
        ]
    };
    const { 0: modal , 1: setModal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: modalProductInfo , 1: setModalProductInfo  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { dealOfTheWeektems , dealOfTheWeekLoading  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.homePageItems.dealOfTheWeek
    );
    //console.log("modal product id", modalProductInfo)
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), {
                ...settings,
                children: dealOfTheWeekLoading ? "Data Loading.." : dealOfTheWeektems.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductItem__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            setModal: setModal,
                            setModalProductInfo: setModalProductInfo,
                            productItemInfo: item,
                            id: index
                        })
                    }, index)
                )
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_Modal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                modal: modal,
                setModal: setModal,
                modalProductInfo: modalProductInfo
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductViewCarouselSlider);

});

/***/ }),

/***/ 3678:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Index),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Home__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7758);
/* harmony import */ var _components_layout_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(838);
/* harmony import */ var _components_MiniCart__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(261);
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(537);
/* harmony import */ var _store_slices_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2135);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_store__WEBPACK_IMPORTED_MODULE_4__, _components_Home__WEBPACK_IMPORTED_MODULE_1__, _components_layout_Layout__WEBPACK_IMPORTED_MODULE_2__]);
([_store_store__WEBPACK_IMPORTED_MODULE_4__, _components_Home__WEBPACK_IMPORTED_MODULE_1__, _components_layout_Layout__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);






function Index(props) {
    //console.log("Index",props)
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_layout_Layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        title: "Home Layout",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_MiniCart__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Home__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
        ]
    }));
};
const getServerSideProps = _store_store__WEBPACK_IMPORTED_MODULE_4__/* .wrapper.getServerSideProps */ .Y.getServerSideProps((store)=>async (ctx)=>{
        await store.dispatch((0,_store_slices_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_5__/* .mainSliderData */ .Uv)());
        //await store.dispatch(categoryData())
        await store.dispatch((0,_store_slices_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_5__/* .brandData */ .Nw)());
        await store.dispatch((0,_store_slices_data_fetch_homePageFetch__WEBPACK_IMPORTED_MODULE_5__/* .dealOfTheWeek */ .k4)());
    }
);

});

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 1143:
/***/ ((module) => {

module.exports = require("@heroicons/react/solid");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 5648:
/***/ ((module) => {

module.exports = require("next-redux-wrapper");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3053:
/***/ ((module) => {

module.exports = require("nookies");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8922:
/***/ ((module) => {

module.exports = require("react-hot-toast");

/***/ }),

/***/ 3611:
/***/ ((module) => {

module.exports = require("react-pure-modal");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,322,838,808,537,656,261,601], () => (__webpack_exec__(3678)));
module.exports = __webpack_exports__;

})();